import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigtion-menu',
  templateUrl: './navigtion-menu.component.html',
  styleUrls: ['./navigtion-menu.component.css']
})
export class NavigtionMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
